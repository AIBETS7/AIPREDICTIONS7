from flask import Flask, jsonify, send_from_directory
from bots.engine import BotEngine
from datetime import datetime
import os

app = Flask(__name__, static_folder='../public', static_url_path='/')
engine = BotEngine(data_path=os.path.join(os.path.dirname(__file__),'data','sample_matches.csv'))

@app.route('/api/site-data.json')
def site_data():
    """Estructura que espera el frontend (main.js): ai_stats, bots, recent_predictions"""
    ai_stats = engine.get_ai_stats()
    bots = engine.get_bots_summary()
    recent_predictions = engine.get_recent_predictions(limit=10)
    payload = {
        "ai_stats": ai_stats,
        "bots": bots,
        "recent_predictions": recent_predictions,
        "last_update": datetime.utcnow().isoformat() + 'Z'
    }
    return jsonify(payload)

@app.route('/api/predictions')
def predictions():
    """Devuelve todas las predicciones (más detalle)"""
    preds = engine.get_recent_predictions(limit=50, detailed=True)
    return jsonify(preds)

# Serve static (index.html + assets) so you can test the full site from Flask during dev:
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8000)), debug=True)
