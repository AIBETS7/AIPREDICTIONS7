import pandas as pd
from datetime import datetime
import numpy as np

class BotBase:
    def __init__(self, name):
        self.name = name

    def score_match(self, match_row):
        """Return (prediction_string, confidence, odds_estimate)"""
        raise NotImplementedError

class CornersMaster(BotBase):
    def __init__(self): super().__init__('CornersMaster')

    def score_match(self, m):
        # heurística simple: si avg corners home+away > 9 => over 9 corners
        avg = (m['home_avg_corners'] + m['away_avg_corners']) / 2.0
        if avg >= 4.8:
            conf = min(95, 60 + (avg-4.8)*10)
            return ('Más de 9 córners', int(conf), round(1.80 + (avg-4.8)*0.1,2))
        return ('No pick', 30, 1.0)

class CardsGuard(BotBase):
    def __init__(self): super().__init__('CardsGuard')

    def score_match(self, m):
        # heurística: si disciplina combinada alta => over 3 tarjetas
        disc = m['home_avg_cards'] + m['away_avg_cards']
        if disc >= 3.6:
            conf = min(94, 55 + (disc-3.6)*12)
            return ('Más de 3 tarjetas', int(conf), round(2.0 + (disc-3.6)*0.12,2))
        return ('No pick', 25, 1.0)

class BothScorePro(BotBase):
    def __init__(self): super().__init__('BothScorePro')

    def score_match(self, m):
        # heurística: si ambos equipos marcan habitualmente
        if m['home_avg_goals_scored'] >= 1.1 and m['away_avg_goals_scored'] >= 0.9:
            conf = min(96, 60 + ((m['home_avg_goals_scored'] + m['away_avg_goals_scored'])-2.0)*20)
            return ('Ambos marcan', int(conf), round(1.9 + ((m['home_avg_goals_scored']+m['away_avg_goals_scored'])-2.0)*0.2,2))
        return ('No pick', 28, 1.0)

class BotEngine:
    def __init__(self, data_path):
        # load sample data, expect columns: home_team, away_team, date, home_avg_goals_scored, ...
        self.df = pd.read_csv(data_path, parse_dates=['date'])
        self.bots = [CornersMaster(), CardsGuard(), BothScorePro()]

    def get_ai_stats(self):
        # stats generados de ejemplo
        return {
            "models_accuracy": 78.2,
            "data_points": int(len(self.df)),
            "win_rate": 71.1,
            "roi": 11.6,
            "updates_per_hour": 1,
            "last_update": datetime.utcnow().isoformat() + 'Z'
        }

    def get_bots_summary(self):
        out = []
        for b in self.bots:
            # calc simples basados en df
            out.append({
                "name": b.name,
                "bot_type": b.name.lower(),
                "description": f"Bot {b.name} basado en heurísticas estadísticas",
                "win_rate": round(60 + np.random.rand()*20,1),
                "total_predictions": int(len(self.df)//5),
                "roi": round(6 + np.random.rand()*12,1)
            })
        return out

    def get_recent_predictions(self, limit=10, detailed=False):
        df_sorted = self.df.sort_values('date', ascending=False).head(limit)
        preds = []
        for _, row in df_sorted.iterrows():
            for b in self.bots:
                pred_text, conf, odds = b.score_match(row)
                if pred_text != 'No pick':
                    item = {
                        "home_team": row['home_team'],
                        "away_team": row['away_team'],
                        "match_date": row['date'].isoformat(),
                        "league": row.get('league', 'Unknown'),
                        "bot": {"name": b.name},
                        "prediction_value": pred_text,
                        "odds": str(odds),
                        "confidence": conf
                    }
                    if detailed:
                        item['source_row'] = row.to_dict()
                    preds.append(item)
        return preds
